<section class="mh-experince" id="mh-experience">
            <div class="bolor-overlay">
                <div class="container">
                    <div class="row section-separator">
                        <div class="col-sm-12 col-md-6">
                            <div class="mh-education">
                                 <h3 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Education</h3>
                                <div class="mh-education-deatils">
                                    <!-- Education Institutes-->
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
                                        <h4>SMAN 2 Purwakarta <a href="#"></a></h4>
                                        <div class="mh-eduyear">2017-2020</div>
                                        
                                    </div>                                
                                    <!-- Education Institutes-->
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.5s">
                                        <h4>Universitas Muhammadiyah Banten <a href="#"> </a></h4>
                                        <div class="mh-eduyear">2022-sekarang</div>
                                        <p>Fakultas teknik dan ilmu komputer,prodi Sistem informasi</p>
                                    </div>                                
                                    </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div class="mh-work">
                                 <h3>Work Experience</h3>
                                <div class="mh-experience-deatils">
                                    <!-- Education Institutes-->
                                    <div class="mh-work-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">
                                        <h4>Universitas Muhammadiyah Banten  <a href="#">magang</a></h4>
                                        <div class="mh-eduyear">2022-sekarang</div>
                                        <span>Responsibility :</span>
                                        <ul class="work-responsibility">
                                            <li><i class="fa fa-circle"></i>menjaga perpustakaan,menjadi admin aplikasi perpustakaan umbanten</li>
                                            
                                        </ul>
                                    </div>                                
                                    <!-- Education Institutes-->
                                    <div class="mh-work-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                        <h4>design<a href="#">freelance</a></h4>
                                        <div class="mh-eduyear">2022-sekarang</div>
                                        <span>Responsibility :</span>
                                        <ul class="work-responsibility">
                                            <li><i class="fa fa-circle"></i>design logo</li>
                                            <li><i class="fa fa-circle"></i>mockup</li>
                                            <li><i class="fa fa-circle"></i>UI design</li>
                                        
                                        </ul>
                                    </div>                                
                                    <!-- Education Institutes-->
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        