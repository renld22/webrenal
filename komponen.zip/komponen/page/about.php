<section class="mh-about" id="mh-about ">
            <div class="container">
                <div class="row section-separator">
                    <div class="col-sm-12 col-md-6 ">
                        <div class="mh-about-img shadow-2 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">
                            <img src="assets/images/ab-img.png" alt="" class="img-fluid">
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <div class="mh-about-inner">
                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">About Me</h2>
                            <p class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Hello, I’m a Renaldi, Saya mempunyai kemampuan untuk bekerja dan bertanggung jawab,mempunyai pengetahuan yang luas dan mudah beradaptasi
                            terhadap lingkungan,saya terus mencari peluang untuk memperluas pengetahuan dan keahlian saya di bidang pengembangan web,



                            </p>
                            <div class="mh-about-tag wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
                                <br>
                                
                                <ul>
                                    <li><span>Nama Renaldi </span></li>
                                    <li><span>Tempat,Tanggal lahir: Purwakarta 6 januari 2002</span></li>
                                    <li><span>alamat : Tangerang,Indonesia</span></li>
                                    <li><span>Status : Lajang</span></li>

                                    
                                </ul>
                                
                                
                                </br>
                            
                                
                                

                            </div>
                            <a href="https://drive.google.com/file/d/1EpOV0Mbd_-MNI4XNue9jgKh-oUvcQaVK/view?usp=sharing" class="btn btn-fill wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">Download CV DISINI<i class="fa fa-download"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        