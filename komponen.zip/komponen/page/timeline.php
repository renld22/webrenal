<div class="container">
                                  
                  
                    <div id="content">

        <h3 class="text-center mt-100" style="font-family: 'Comic Sans MS', cursive;">2023 timeline of my activities</h3>
                          
    
                        <ul class="timeline">
                            <li class="event" data-date="UAS dan Ulang Tahun">
                                <h3>Januari</h3>
                                <div class="timeline-icon"><i class="fa fa-book"></i><i class="fa fa-birthday-cake "></i></div>
                              
                              <p>Ujian Akhir Semester pada tanggal 2 sd 6 januari dan ulang tahun pada 6 januari</p>
                            </li>
                            <li class="event" data-date="masuk kuliah">
                                <h3>Februari</h3>
                                <div class="timeline-icon"><i class="fa fa-university"></i></div>
                                <p>masuk kuliah semester 2  </p>
                            </li>
                            <li class="event" data-date="Promosi kampus">
                                <h3>Maret</h3>
                                <div class="timeline-icon"><i class="fa fa-bus"></i></div>
                                
                                <p>Promosi kampus ke setiap sekolah SMA dan SMK</p>
                            </li>
                            <li class="event" data-date="Puasa dan UTS">
                               
                                <h3>April</h3>
                                <div class="timeline-icon"><i class="fa fa-moon-o "></i><i class="fa fa-book "></i></div>
                              
                               
                                <p>Puasa Ramadhan dan melaksanakan Ujian Tengah Semester</p>
                            </li>
                            <li class="event" data-date="Lebaran dan mudik">
                                <h3>Mei</h3>
                                 <div class="timeline-icon"><i class="fa fa-moon-o"></i><i class="fa fa-bus "></i></div>
                              
                               
                                <p>mudik libur kuliah lebaran idul fitri,merayakan hari raya idul fitri</p>
                            </li>
                            <li class="event" data-date="UAS dan panitia Futsal">
                                <h3>Juni</h3>
                                <div class="timeline-icon"><i class="fa fa-book"></i><i class="fa fa-futbol-o   "></i></div>
                              
                                <p>panitia futsal piala UMbanten dan Uas pada tanggal 19 sd 22 juni</p>
                            </li>
                            <li class="event" data-date="Libur Kuliah dan mudik">
                                <h3>Juli</h3>
                                 <div class="timeline-icon"><i class="fa fa-ticket"></i><i class="fa fa-odnoklassniki    "></i></div>
                              
                                <p>libur kuliah ,workout pagi pagi  </p>
                            </li>
                            <li class="event" data-date="Panitia HUT RI">
                                <h3>Agustus</h3>
                                <div class="timeline-icon"><i class="fa fa-flag-o"></i></div>
                                
                                <p>Panitia perlombaan 17 agustus</p>
                            </li>
                            <li class="event" data-date="Masuk Kuliah">
                                <h3>September</h3>
                                <div class="timeline-icon"><i class="fa fa-university"></i></div>
                                
                                <p>Masuk kuliah Semester 3 </p>
                            </li>
                            <li class="event" data-date="dicoding bangun negeri">
                                <h3>Oktober</h3>
                                <div class="timeline-icon"><i class="fa fa-github "></i></div>
                                
                                <p>mengikuti beasiswa dicoding bangun negeri</p>
                            </li>
                            <li class="event" data-date="Acara Public Speaking">
                                <h3>November</h3>
                                <div class="timeline-icon"><i class="fa fa-microphone  "></i></div>
                                
                                <p>mengikuti acara seminar Public Speaking bersama Vice President NET TV </p>
                            </li>
                            <li class="event" data-date="DAD,Panitia Wisuda">
                                <h3>Desember</h3>
                                 <div class="timeline-icon"><i class="fa fa-moon-o"></i><i class="fa fa-graduation-cap  "></i></div>
                              
                                <p>mengikuti DAD (Darul Arqam Dasar),Panitia Wisuda Universitas Muhammadiyah Banten</p>
                            </li>
                        </ul>
                    </div>
                
    </div>
</div>